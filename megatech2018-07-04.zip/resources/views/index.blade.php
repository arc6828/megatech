@extends('template/template')
@section('content')
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<section class="resume-section p-3 p-lg-5 d-flex d-column">
	 	<div class="container">
	 		</div>
</section>
</body>
</html>
@endsection