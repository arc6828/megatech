<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<section class="resume-section p-3 p-lg-5 d-flex d-column">
	 	<div class="container">
	 		</div>
</section>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>