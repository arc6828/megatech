<?php

namespace App\Sales;

use Illuminate\Database\Eloquent\Model;

class RequisitionModel extends Model
{
    //
}
