<script type="text/javascript" src="<?php echo e(url('/')); ?>/js/app.js"></script>
Hello World