@extends('monster-lite/layouts/theme')

@section('title','Blank Page')

@section('content')

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-block">
                This is some text within a card block.
            </div>
        </div>
    </div>
</div>

@endsection


@section('plugins-js')
<!-- BLANK -->
@endsection