<div class="card">
  <div class="card-block">      
    <div class="row text-center">
      <div class="col-6">
        <a class="btn btn-outline-primary my-3" href="{{url('/')}}/">
          <div class="px-4"><span class="round round-primary my-2">ค</span></i></div>
          <div><br>ผ่านเช็ครับ</div>
        </a>
      </div>
      <div class="col-6">
        <a class="btn btn-outline-primary my-3" href="{{url('/')}}/">
          <div class="px-4"><span class="round round-primary my-2">น</span></div>
          <div><br>ผ่านเช็ครับ</div>            
        </a>
      </div>
      <div class="col-6">
        <a class="btn btn-outline-primary my-3" href="#">
          <div class="px-4"><span class="round round-primary my-2">ล</span></i></div>
          <div>ยกเลิก<br>เช็ครับ</div>            
        </a>
      </div>
      <div class="col-6">
        <a class="btn btn-outline-primary my-3" href="#">            
          <div class="px-4"><span class="round round-primary my-2">บ</span></i></div>
          <div>ยกเลิก<br>เช็คจ่าย</div>
        </a>
      </div>             
    </div>      
  </div>  
</div> 