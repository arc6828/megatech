<script type="text/javascript" src="{{ url('/') }}/js/app.js"></script>
Hello World